"""
Notification Service – Empfängt Benachrichtigungen und streamt sie per SSE.
Daten werden in data/notifications.json gespeichert.
"""
from fastapi import FastAPI
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
import json, os, time, asyncio, uuid

app = FastAPI(title="Notification Service",
              description="Benachrichtigungen & Server-Sent Events (SSE)", version="1.0.0")

DATA_FILE = os.getenv("DATA_FILE", "data/notifications.json")

# In-Memory Queue für aktive SSE-Clients
_sse_queues: list[asyncio.Queue] = []

# ── Pydantic-Modelle ───────────────────────────────────────────────────────────
class NotificationIn(BaseModel):
    order_id: str
    email: str
    status: str      # confirmed | cancelled | shipped ...
    timestamp: float | None = None

class Notification(NotificationIn):
    id: str
    received_at: float

# ── Datei-Persistenz ───────────────────────────────────────────────────────────
def _load() -> list:
    os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)
    if not os.path.exists(DATA_FILE):
        _save([])
    with open(DATA_FILE) as f:
        return json.load(f)

def _save(data: list):
    os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=2)

# ── Endpunkte ──────────────────────────────────────────────────────────────────
@app.post("/notifications", response_model=Notification, status_code=201, tags=["Notifications"])
async def receive_notification(body: NotificationIn):
    """
    Neue Benachrichtigung speichern und an alle SSE-Clients pushen.
    Wird typischerweise vom Order-Service aufgerufen.
    """
    notif = Notification(
        id=str(uuid.uuid4()),
        received_at=time.time(),
        timestamp=body.timestamp or time.time(),
        **{k: v for k, v in body.model_dump().items() if k != "timestamp"},
    )
    db = _load()
    db.append(notif.model_dump())
    _save(db)

    # An alle wartenden SSE-Clients senden
    event_data = json.dumps(notif.model_dump())
    for q in list(_sse_queues):
        await q.put(event_data)

    return notif

@app.get("/notifications", response_model=list[Notification], tags=["Notifications"])
async def list_notifications():
    """Alle gespeicherten Benachrichtigungen abrufen."""
    return _load()

@app.get("/notifications/stream", tags=["Notifications"])
async def sse_stream():
    """
    Server-Sent Events (SSE) Stream.
    Verbinde dich hier, um Live-Benachrichtigungen zu empfangen.
    Im Browser: `const es = new EventSource('http://localhost:8004/notifications/stream')`
    """
    queue: asyncio.Queue = asyncio.Queue()
    _sse_queues.append(queue)

    async def event_generator():
        # Willkommensnachricht
        yield "data: {\"message\": \"Verbunden mit Notification-Stream\"}\n\n"
        try:
            while True:
                # Heartbeat alle 15 Sekunden damit die Verbindung offen bleibt
                try:
                    data = await asyncio.wait_for(queue.get(), timeout=15)
                    yield f"data: {data}\n\n"
                except asyncio.TimeoutError:
                    yield ": heartbeat\n\n"
        except asyncio.CancelledError:
            pass
        finally:
            _sse_queues.remove(queue)

    return StreamingResponse(event_generator(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache",
                                      "X-Accel-Buffering": "no"})

@app.get("/metrics", tags=["Monitoring"])
async def metrics():
    return {
        "service": "notification-service",
        "status": "ok",
        "total_notifications": len(_load()),
        "active_sse_clients": len(_sse_queues),
        "uptime": int(time.time()),
    }

@app.get("/health", tags=["Monitoring"])
async def health():
    return {"status": "ok"}
