"""
Gateway Service – Einziger Zugangspunkt von außen.
Kümmert sich um Login/JWT und leitet Anfragen weiter.
"""
from fastapi import FastAPI, Depends, HTTPException, Security, Request, Response
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
import httpx
import jwt
import time
import os

app = FastAPI(
    title="Gateway Service",
    description="Zentraler Zugangspunkt – Login & Routing",
    version="1.0.0",
)

# ── Konfiguration ──────────────────────────────────────────────────────────────
SECRET_KEY = os.getenv("JWT_SECRET", "super-geheimes-jwt-secret")
ALGORITHM = "HS256"
TOKEN_TTL = 3600  # 1 Stunde

SERVICE_URLS = {
    "products":     os.getenv("PRODUCT_SERVICE_URL",      "http://product-service:8001"),
    "inventory":    os.getenv("INVENTORY_SERVICE_URL",    "http://inventory-service:8002"),
    "orders":       os.getenv("ORDER_SERVICE_URL",        "http://order-service:8003"),
    "notifications":os.getenv("NOTIFICATION_SERVICE_URL","http://notification-service:8004"),
}

# Fake-Nutzerdatenbank (für die Demo)
USERS = {
    "admin": "password",
    "user":  "user123",
}

security = HTTPBearer()

# ── Pydantic-Modelle ───────────────────────────────────────────────────────────
class LoginRequest(BaseModel):
    username: str
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int = TOKEN_TTL

# ── JWT-Hilfsfunktionen ────────────────────────────────────────────────────────
def create_token(username: str) -> str:
    payload = {
        "sub": username,
        "iat": int(time.time()),
        "exp": int(time.time()) + TOKEN_TTL,
    }
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)

def verify_token(credentials: HTTPAuthorizationCredentials = Security(security)) -> dict:
    try:
        payload = jwt.decode(credentials.credentials, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Token abgelaufen")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Ungültiger Token")

# ── Endpunkte ──────────────────────────────────────────────────────────────────
@app.post("/login", response_model=TokenResponse, tags=["Auth"])
async def login(body: LoginRequest):
    """Anmelden und JWT-Token erhalten. Beispiel: admin / password"""
    if USERS.get(body.username) != body.password:
        raise HTTPException(status_code=401, detail="Ungültige Anmeldedaten")
    token = create_token(body.username)
    return TokenResponse(access_token=token)


async def _proxy(method: str, url: str, request: Request) -> Response:
    """Generischer Proxy – leitet Anfrage an Backend-Service weiter."""
    body = await request.body()
    headers = {k: v for k, v in request.headers.items() if k.lower() != "host"}
    async with httpx.AsyncClient(timeout=10) as client:
        resp = await client.request(method, url, content=body, headers=headers,
                                    params=dict(request.query_params))
    return Response(content=resp.content, status_code=resp.status_code,
                    media_type=resp.headers.get("content-type", "application/json"))


@app.api_route("/api/products/{path:path}", methods=["GET","POST","PUT","DELETE"], tags=["Products"])
async def proxy_products(path: str, request: Request, _: dict = Depends(verify_token)):
    """Leitet Anfragen an den Product-Service weiter (JWT erforderlich)."""
    url = f"{SERVICE_URLS['products']}/products/{path}"
    return await _proxy(request.method, url, request)

@app.api_route("/api/products", methods=["GET","POST"], tags=["Products"])
async def proxy_products_root(request: Request, _: dict = Depends(verify_token)):
    url = f"{SERVICE_URLS['products']}/products"
    return await _proxy(request.method, url, request)

@app.api_route("/api/inventory/{path:path}", methods=["GET","POST","PUT","DELETE"], tags=["Inventory"])
async def proxy_inventory(path: str, request: Request, _: dict = Depends(verify_token)):
    """Leitet Anfragen an den Inventory-Service weiter (JWT erforderlich)."""
    url = f"{SERVICE_URLS['inventory']}/inventory/{path}"
    return await _proxy(request.method, url, request)

@app.api_route("/api/orders/{path:path}", methods=["GET","POST","PUT","DELETE"], tags=["Orders"])
async def proxy_orders(path: str, request: Request, _: dict = Depends(verify_token)):
    """Leitet Anfragen an den Order-Service weiter (JWT erforderlich)."""
    url = f"{SERVICE_URLS['orders']}/orders/{path}"
    return await _proxy(request.method, url, request)

@app.api_route("/api/orders", methods=["GET","POST"], tags=["Orders"])
async def proxy_orders_root(request: Request, _: dict = Depends(verify_token)):
    url = f"{SERVICE_URLS['orders']}/orders"
    return await _proxy(request.method, url, request)

@app.get("/api/notifications/stream", tags=["Notifications"])
async def proxy_sse(request: Request, _: dict = Depends(verify_token)):
    """SSE-Stream vom Notification-Service (JWT erforderlich)."""
    url = f"{SERVICE_URLS['notifications']}/notifications/stream"
    return await _proxy("GET", url, request)


@app.get("/metrics", tags=["Monitoring"])
async def metrics():
    return {
        "service": "gateway-service",
        "status": "ok",
        "uptime_seconds": int(time.time()),
        "routes": list(SERVICE_URLS.keys()),
    }

@app.get("/health", tags=["Monitoring"])
async def health():
    return {"status": "ok"}
