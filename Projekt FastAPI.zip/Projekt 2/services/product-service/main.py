"""
Product Service – Verwaltet den Produktkatalog.
Daten werden in data/products.json gespeichert.
"""
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Optional
import json, os, time, uuid

app = FastAPI(title="Product Service", description="Produktverwaltung", version="1.0.0")

DATA_FILE = os.getenv("DATA_FILE", "data/products.json")

# ── Pydantic-Modelle ───────────────────────────────────────────────────────────
class ProductBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=100, example="Laptop Pro 15")
    description: str = Field("", example="Leistungsstarker Laptop")
    price: float = Field(..., gt=0, example=999.99)
    category: str = Field("general", example="electronics")

class ProductCreate(ProductBase):
    pass

class Product(ProductBase):
    id: str
    created_at: float

# ── Datei-Persistenz ───────────────────────────────────────────────────────────
def _load() -> dict:
    os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)
    if not os.path.exists(DATA_FILE):
        _save({})
    with open(DATA_FILE) as f:
        return json.load(f)

def _save(data: dict):
    os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)
    with open(DATA_FILE, "w") as f:
        json.dump(data, f, indent=2)

# ── Endpunkte ──────────────────────────────────────────────────────────────────
@app.get("/products", response_model=list[Product], tags=["Products"])
async def list_products():
    """Alle Produkte auflisten."""
    return list(_load().values())

@app.post("/products", response_model=Product, status_code=201, tags=["Products"])
async def create_product(body: ProductCreate):
    """Neues Produkt anlegen."""
    db = _load()
    product = Product(id=str(uuid.uuid4()), created_at=time.time(), **body.model_dump())
    db[product.id] = product.model_dump()
    _save(db)
    return product

@app.get("/products/{product_id}", response_model=Product, tags=["Products"])
async def get_product(product_id: str):
    """Ein Produkt per ID abrufen."""
    db = _load()
    if product_id not in db:
        raise HTTPException(404, "Produkt nicht gefunden")
    return db[product_id]

@app.put("/products/{product_id}", response_model=Product, tags=["Products"])
async def update_product(product_id: str, body: ProductBase):
    """Produkt aktualisieren."""
    db = _load()
    if product_id not in db:
        raise HTTPException(404, "Produkt nicht gefunden")
    updated = {**db[product_id], **body.model_dump()}
    db[product_id] = updated
    _save(db)
    return updated

@app.delete("/products/{product_id}", tags=["Products"])
async def delete_product(product_id: str):
    """Produkt löschen."""
    db = _load()
    if product_id not in db:
        raise HTTPException(404, "Produkt nicht gefunden")
    del db[product_id]
    _save(db)
    return {"message": "Produkt gelöscht"}

@app.get("/metrics", tags=["Monitoring"])
async def metrics():
    return {"service": "product-service", "status": "ok",
            "product_count": len(_load()), "uptime": int(time.time())}

@app.get("/health", tags=["Monitoring"])
async def health():
    return {"status": "ok"}
