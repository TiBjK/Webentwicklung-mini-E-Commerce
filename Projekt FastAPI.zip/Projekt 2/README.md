# 🛒 Micro-E-Commerce – Projektarbeit

Ein einfaches Microservices-System mit **FastAPI**, **Docker** und **Kubernetes**.  
Alle Services kommunizieren per REST/JSON. Live-Benachrichtigungen laufen über **Server-Sent Events (SSE)**.  
Das UI ist die von FastAPI automatisch generierte **Swagger-UI** – keine extra Frontend-Arbeit nötig.

---

## 📁 Projektstruktur

```
micro-ecommerce/
├── services/
│   ├── gateway-service/       # Port 8000 – Login & Routing
│   ├── product-service/       # Port 8001 – Produkte
│   ├── inventory-service/     # Port 8002 – Lagerbestände
│   ├── order-service/         # Port 8003 – Bestellungen
│   └── notification-service/  # Port 8004 – SSE-Benachrichtigungen
├── docker-compose.yml
├── kubernetes.yaml
└── README.md
```

Jeder Service hat: `main.py` · `requirements.txt` · `Dockerfile` · `data/` (JSON-Persistenz)

---

## 🔧 Voraussetzungen

| Tool | Version | Download |
|------|---------|---------|
| **Python** | 3.12+ | https://python.org |
| **Docker Desktop** | aktuell | https://docker.com/products/docker-desktop |
| **kubectl** | aktuell | https://kubernetes.io/docs/tasks/tools/ |

---

## 🚀 Lokal starten (Docker Compose)

```bash
# Im Hauptordner des Projekts:
docker-compose up --build

# Alle Services stoppen:
docker-compose down

# Volumes (gespeicherte JSON-Daten) komplett löschen:
docker-compose down -v
```

Nach dem Start sind alle Services erreichbar:

| Service | Swagger-UI | Direkte API |
|---------|-----------|-------------|
| **Gateway** | http://localhost:8000/docs | http://localhost:8000 |
| Product | http://localhost:8001/docs | http://localhost:8001 |
| Inventory | http://localhost:8002/docs | http://localhost:8002 |
| Order | http://localhost:8003/docs | http://localhost:8003 |
| Notification | http://localhost:8004/docs | http://localhost:8004 |

> **Tipp:** Für die Projektpräsentation reicht es, nur `http://localhost:8000/docs` zu zeigen – das ist unser offizielles UI!

---

## ☸️ Kubernetes deployen

### Voraussetzung: Images bauen

Kubernetes braucht fertige Docker-Images. Für lokales Testen mit **minikube**:

```bash
# minikube Docker-Registry nutzen
eval $(minikube docker-env)

# Alle Images bauen
docker build -t micro-ecommerce/gateway-service:latest      ./services/gateway-service
docker build -t micro-ecommerce/product-service:latest      ./services/product-service
docker build -t micro-ecommerce/inventory-service:latest    ./services/inventory-service
docker build -t micro-ecommerce/order-service:latest        ./services/order-service
docker build -t micro-ecommerce/notification-service:latest ./services/notification-service
```

### Deployment

```bash
# Alles deployen (Namespace, PVCs, Deployments, Services, Ingress)
kubectl apply -f kubernetes.yaml

# Status prüfen
kubectl get all -n micro-ecommerce

# Logs eines Services anzeigen
kubectl logs -n micro-ecommerce deployment/gateway-service -f

# Gateway-URL bei minikube
minikube service gateway-service -n micro-ecommerce --url

# Alles wieder löschen
kubectl delete -f kubernetes.yaml
```

---

## 🔐 API testen (Schritt-für-Schritt)

### 1. Einloggen und Token holen

Öffne `http://localhost:8000/docs` → **POST /login**

```json
{
  "username": "admin",
  "password": "password"
}
```

Kopiere den `access_token` aus der Antwort.

**Weitere Test-Accounts:**
| User | Password |
|------|---------|
| `admin` | `password` |
| `user` | `user123` |

### 2. Token in Swagger-UI eintragen

Klick auf **🔒 Authorize** (oben rechts) → `Bearer <dein-token>` eintragen.

### 3. Produkt anlegen (via Gateway)

**POST /api/products**
```json
{
  "name": "Laptop Pro 15",
  "description": "Leistungsstarker Laptop für Studierende",
  "price": 999.99,
  "category": "electronics"
}
```

### 4. Lagerbestand setzen

**PUT /api/inventory/{product_id}** (ID aus Schritt 3 verwenden)
```json
{ "quantity": 50 }
```

### 5. Bestellung aufgeben

**POST /api/orders**
```json
{
  "customer_name": "Max Mustermann",
  "customer_email": "max@example.com",
  "items": [
    {
      "product_id": "<product_id_aus_schritt_3>",
      "quantity": 2,
      "unit_price": 999.99
    }
  ]
}
```

Der Order-Service reserviert automatisch den Bestand und schickt eine Benachrichtigung!

### 6. Live-Benachrichtigungen (SSE)

In einem neuen Browser-Tab oder Terminal:

```bash
# Terminal (curl)
curl -N http://localhost:8004/notifications/stream

# JavaScript (Browser-Konsole)
const es = new EventSource('http://localhost:8004/notifications/stream');
es.onmessage = e => console.log(JSON.parse(e.data));
```

---

## 📊 Architektur

```
Browser / Swagger-UI
        │
        ▼
┌───────────────────┐
│   Gateway :8000   │  ← Login (JWT) + Proxy
└────────┬──────────┘
         │  HTTP (REST/JSON)
    ┌────┴────────────────────────────┐
    │            │           │        │
    ▼            ▼           ▼        ▼
Product      Inventory    Order   Notification
:8001         :8002       :8003     :8004
  │                         │         │
  │         Reserve ────────┘         │
  │         Stock                     │
  └── JSON Files ──┘         SSE ─────┘
     (PVCs in K8s)
```

---

## 🐛 Troubleshooting

**Services starten nicht:**  
```bash
docker-compose logs <service-name>
```

**"Connection refused" zwischen Services:**  
Prüfe ob alle Container laufen: `docker-compose ps`

**Token abgelaufen:**  
JWT ist 1 Stunde gültig – einfach neu einloggen.

**Kubernetes: ImagePullBackOff:**  
Images wurden nicht in die minikube-Registry gebaut. Siehe Abschnitt "Images bauen".
