import express from 'express';
import cors from 'cors';

const app = express();
app.use(cors());
app.use(express.json());

// productId -> stock
let inventory = {
  1: 10,
  2: 5,
  3: 20
};

app.get('/inventory/:productId', (req, res) => {
  const productId = req.params.productId;
  const stock = inventory[productId] ?? 0;
  res.json({ productId, stock });
});

app.post('/inventory/reserve', (req, res) => {
  const { productId, quantity } = req.body;
  const current = inventory[productId] ?? 0;

  if (current < quantity) {
    return res.status(400).json({ success: false, message: 'Not enough stock' });
  }

  inventory[productId] = current - quantity;
  res.json({ success: true, productId, remaining: inventory[productId] });
});

const PORT = 4002;
app.listen(PORT, () => {
  console.log(`Inventory Service running on port ${PORT}`);
});
