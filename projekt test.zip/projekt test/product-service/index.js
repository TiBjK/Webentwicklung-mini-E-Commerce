import express from 'express';
import cors from 'cors';
import swaggerUi from 'swagger-ui-express';
import swaggerJsdoc from 'swagger-jsdoc';

const app = express();

const swaggerOptions = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'Product Service API',
      version: '1.0.0',
      description: 'API Dokumentation für den Product Service'
    }
  },
  apis: ['./index.js'] // <- Swagger liest die Kommentare in dieser Datei
};

const swaggerSpec = swaggerJsdoc(swaggerOptions);
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));

app.use(cors());
app.use(express.json());

let products = [
  { id: 1, name: 'T-Shirt', price: 19.99 },
  { id: 2, name: 'Hoodie', price: 39.99 },
  { id: 3, name: 'Cap',    price: 14.99 }
];

/**
 * @openapi
 * /products:
 *   get:
 *     summary: Gibt alle Produkte zurück
 *     tags:
 *       - Products
 *     responses:
 *       200:
 *         description: Erfolgreiche Antwort
 */
app.get('/products', (req, res) => {
  res.json(products);
});

/**
 * @openapi
 * /products/{id}:
 *   get:
 *     summary: Gibt ein Produkt anhand der ID zurück
 *     tags:
 *       - Products
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Produkt gefunden
 *       404:
 *         description: Produkt nicht gefunden
 */
app.get('/products/:id', (req, res) => {
  const id = Number(req.params.id);
  const product = products.find(p => p.id === id);
  if (!product) return res.status(404).json({ message: 'Product not found' });
  res.json(product);
});

/**
 * @openapi
 * /products:
 *   post:
 *     summary: Erstellt ein neues Produkt
 *     tags:
 *       - Products
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               price:
 *                 type: number
 *     responses:
 *       201:
 *         description: Produkt erstellt
 */
app.post('/products', (req, res) => {
  const { name, price } = req.body;
  const id = products.length ? Math.max(...products.map(p => p.id)) + 1 : 1;
  const newProduct = { id, name, price };
  products.push(newProduct);
  res.status(201).json(newProduct);
});

const PORT = 4001;
app.listen(PORT, () => {
  console.log(`Product Service running on port ${PORT}`);
});
