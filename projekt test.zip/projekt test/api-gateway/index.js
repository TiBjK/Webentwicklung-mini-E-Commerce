import express from 'express';
import cors from 'cors';
import { createProxyMiddleware } from 'http-proxy-middleware';

const app = express();
app.use(cors());
app.use(express.json());

// Product Service
app.use(
  '/products',
  createProxyMiddleware({
    target: 'http://localhost:4001',
    changeOrigin: true
  })
);

// Inventory Service
app.use(
  '/inventory',
  createProxyMiddleware({
    target: 'http://localhost:4002',
    changeOrigin: true
  })
);

// Notification Service
app.use(
  '/notify',
  createProxyMiddleware({
    target: 'http://localhost:4003',
    changeOrigin: true
  })
);

// Order Service
app.use(
  '/orders',
  createProxyMiddleware({
    target: 'http://localhost:4004',
    changeOrigin: true
  })
);

const PORT = 4000;
app.listen(PORT, () => {
  console.log(`API Gateway running on port ${PORT}`);
});
