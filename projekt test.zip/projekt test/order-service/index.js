import express from 'express';
import cors from 'cors';
import axios from 'axios';

const app = express();
app.use(cors());
app.use(express.json());

let orders = [];
let nextOrderId = 1;

const INVENTORY_URL = 'http://localhost:4002';
const NOTIFICATION_URL = 'http://localhost:4003';

app.get('/orders', (req, res) => {
  res.json(orders);
});

app.get('/orders/:id', (req, res) => {
  const id = Number(req.params.id);
  const order = orders.find(o => o.id === id);
  if (!order) return res.status(404).json({ message: 'Order not found' });
  res.json(order);
});

app.post('/orders', async (req, res) => {
  const { customerEmail, items } = req.body;
  // items: [{ productId, quantity }, ...]

  try {
    // 1. Bestand prüfen & reservieren
    for (const item of items) {
      const resp = await axios.post(`${INVENTORY_URL}/inventory/reserve`, {
        productId: item.productId,
        quantity: item.quantity
      });
      if (!resp.data.success) {
        return res.status(400).json({ message: 'Inventory reservation failed' });
      }
    }

    // 2. Bestellung anlegen
    const order = {
      id: nextOrderId++,
      customerEmail,
      items,
      status: 'CREATED',
      createdAt: new Date().toISOString()
    };
    orders.push(order);

    // 3. Benachrichtigung senden
    await axios.post(`${NOTIFICATION_URL}/notify`, {
      type: 'ORDER_CREATED',
      to: customerEmail,
      message: `Danke für deine Bestellung #${order.id}`
    });

    res.status(201).json(order);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ message: 'Order creation failed' });
  }
});

const PORT = 4004;
app.listen(PORT, () => {
  console.log(`Order Service running on port ${PORT}`);
});
