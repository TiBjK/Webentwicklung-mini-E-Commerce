import express from 'express';
import cors from 'cors';

const app = express();
app.use(cors());
app.use(express.json());

app.post('/notify', (req, res) => {
  const { type, to, message } = req.body;
  console.log(`[Notification] type=${type}, to=${to}, message=${message}`);
  // Hier könnte später z.B. E-Mail, Webhook, etc. kommen
  res.json({ success: true });
});

const PORT = 4003;
app.listen(PORT, () => {
  console.log(`Notification Service running on port ${PORT}`);
});
